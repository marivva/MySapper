import Model.Executer.MainWork;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        MainWork game = new MainWork();
        game.run(0);
    }
}
