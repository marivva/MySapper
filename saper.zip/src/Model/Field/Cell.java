package Model.Field;

public enum Cell {
    UNKNOWN(10),
    EMPTY(11),
    BOMB(12),
    FLAG(13),
    OPEN(14),
    ONE (1),
    TWO(2),
    THREE(3),
    FOUR(4),
    FIVE(5);

    Cell(int i) {
    }
}
