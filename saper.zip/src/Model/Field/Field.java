package Model.Field;

public class Field {
    private Cell[] field;
    private int size;
    public Field(int size) {
        this.size = size;
        field = new Cell[size * size];
        for (int i = 0; i < size * size; i++){
            field[i] = Cell.UNKNOWN;
        }
    }       //создаем поле для игры размером size*size
    public Cell getCell(int x, int y){
        int coordinate = y * size + x;
        return field[coordinate];
    }
    public void setCell(int x, int y, Cell value){
        int coordinate = y  * size + x;
        field[coordinate] = value;
    }
}
