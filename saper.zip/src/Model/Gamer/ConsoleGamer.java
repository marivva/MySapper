package Model.Gamer;

import Model.Field.Field;

public class ConsoleGamer {
    public Field gamerField;
    public int gamerScore;
    public String gamerName;
    public int openedCells;
    public ConsoleGamer(String gamerName){
        gamerScore = 0;
        this.gamerName = gamerName;
        gamerField = new Field(10);
        openedCells = 0;
    }
}
