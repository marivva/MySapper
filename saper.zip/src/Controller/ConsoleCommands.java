package Controller;

import Model.Executer.Mode;

import java.util.Scanner;

public class ConsoleCommands implements Command {
    public int x = 0;
    public int y = 0;
    public Mode desire = Mode.UNKNOWN;
    @Override
    public void getDesireAndCoordinates() {
        Scanner scan = new Scanner(System.in);
        //узнаем что пользовтель хочет сделать с клеткой, пока не введут корректное значение
        boolean correct = false;
        while (!correct) {
            System.out.println(">>Enter what you want (open cell/make flag/new game/about/exit/high scores): ");
            String modeStr = scan.nextLine();
            if (modeStr.compareTo("open cell") == 0) {
                correct = true;
                desire = Mode.OPEN;
            }
            if (modeStr.compareTo("make flag") == 0) {
                desire = Mode.FLAG;
                correct = true;
            }
            if (modeStr.compareTo("new game") == 0) {
                desire = Mode.NEW_GAME;
                correct = true;
            }
            if (modeStr.compareTo("about") == 0) {
                desire = Mode.ABOUT;
                correct = true;
            }
            if (modeStr.compareTo("exit") == 0) {
                desire = Mode.EXIT;
                correct = true;
            }
            if (modeStr.compareTo("high scores") == 0) {
                desire = Mode.HIGH_SCORES;
                correct = true;
            }
        }
        //если ввели открыть/поставить флаг, то спрашиваем координаты
        if (desire == Mode.OPEN || desire == Mode.FLAG) {
            //спрашивем координаты, пока они не окажутся корректными
            x = -1;
            y = -1;
            while (x == -1 || y == -1) {
                System.out.println(">>Enter x coordinate: ");
                int userX = scan.nextInt();
                System.out.println(">>Enter y coordinate: ");
                int userY = scan.nextInt();
                if (userX >= 0 && userX <= 9 && userY >= 0 && userY <= 9) {
                    x = userX;
                    y = userY;
                }
            }
        }
    }
    @Override
    public boolean getInf(){
        System.out.println(">>Do you want play new game?(yes/no)");
        Scanner scanner = new Scanner(System.in);
        String answer = scanner.nextLine();
        boolean correct = false;
        if(answer.compareTo("yes") == 0 || answer.compareTo("no") == 0) correct = true;
        else
            while (answer.compareTo("yes") != 0 || answer.compareTo("no") != 0) {
                System.out.println(">>Do you want play new game?(yes/no)");
                answer = scanner.nextLine();
            }
        if (answer.compareTo("yes") == 0) return true;
        else return false;
    }
    @Override
    public int getX(){return x;}
    @Override
    public int getY(){return y;}
    @Override
    public Mode getDesire(){return desire;}
    @Override
    public String getName(){
        System.out.println("Enter your name (without spaces):");
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        return name;
    }
}
