package View;

import Model.Field.Field;

import java.io.IOException;

public interface GameView {
    public void drawField(Field field);
    public void printReference();
    public void printHighScores();
    public void printScore(int score);
    public void printName(String name);
    public void saveScore(String name, int score) throws IOException;
    public void printWinner();
    public void printLoser();
}
