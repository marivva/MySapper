package Controller;

import AskGamer.Command;
import AskGamer.ConsoleCommands;
import Field.Field;
import Field.Cell;
import Gamer.ConsoleGamer;
import View.ConsoleView;
import View.GameView;

import java.io.IOException;

import static Field.Cell.*;

public class GameController {
    private Field mainField;
    private boolean new_game = false;
    private boolean gameOver = false;
    private boolean exit = false;
    private void check_cells_around(int x, int y){
        switch (mainField.getCell(x, y)){
            case UNKNOWN: mainField.setCell(x, y, Cell.ONE); break;
            case ONE: mainField.setCell(x, y, Cell.TWO); break;
            case TWO: mainField.setCell(x, y, Cell.THREE); break;
            case THREE: mainField.setCell(x, y, Cell.FOUR); break;
            case FOUR: mainField.setCell(x, y, Cell.FIVE); break;
        }
    }
    private void fillField(){
        int max = 10;
        int[] Xcoordinates = new int[5];
        int[] Ycootdinates = new int[5];
        int countFilledCells = 5;
        //устанавливаем на поле 5 бомб на произвольные позиции
        for(int i = 0; i < 5; i++){
            int x = (int)(Math.random() * max);
            int y = (int)(Math.random() * max);
            while(mainField.getCell(x, y) != UNKNOWN){
                x = (int)(Math.random() * max);
                y = (int)(Math.random() * max);
            }
            Xcoordinates[i] = x;
            Ycootdinates[i] = y;
            mainField.setCell(x, y, Cell.BOMB);
        }
        //заполняем клетки с цифрами
        for(int i = 0; i < 5; i++) {
            if(Xcoordinates[i] == 0){
                if(Ycootdinates[i] == 0){
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    countFilledCells += 3;
                }
                if(Ycootdinates[i] == 9){
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    countFilledCells += 3;
                }
                if (Ycootdinates[i] != 0 && Ycootdinates[i] != 9) {
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    countFilledCells += 5;
                }
            }
            if(Xcoordinates[i] == 9){
                if(Ycootdinates[i] == 0){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    countFilledCells += 3;
                }
                if(Ycootdinates[i] == 9){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    countFilledCells += 3;
                }
                if (Ycootdinates[i] != 0 && Ycootdinates[i] != 9) {
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                     countFilledCells += 5;
                }
            }
            if(Xcoordinates[i] != 0 && Xcoordinates[i] != 9){
                if(Ycootdinates[i] == 0){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    countFilledCells += 5;
                }
                if(Ycootdinates[i] == 9){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    countFilledCells += 5;
                }
                if (Ycootdinates[i] != 0 && Ycootdinates[i] != 9) {
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    countFilledCells += 8;
                }
            }
        }
        int remains = 100 - countFilledCells;
        //заполняем оставшиеся клетки пустыми значениями
        for(int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (mainField.getCell(i, j) == UNKNOWN) mainField.setCell(i, j, EMPTY);
            }
        }
    }
    private void setEmptyCells(int x, int y, ConsoleGamer gamer){
        if(x == 0){
            if(y == 0){
                if (mainField.getCell(x + 1, y) == EMPTY && gamer.gamerField.getCell(x + 1, y) != EMPTY){
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y, gamer);
                }
                if (mainField.getCell(x, y + 1) == EMPTY && gamer.gamerField.getCell(x, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y + 1, gamer);
                }
                if (mainField.getCell(x + 1, y + 1) == EMPTY && gamer.gamerField.getCell(x + 1, y + 1) != EMPTY){
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y + 1, gamer);
                }
            }
            if(y == 9){
                if (mainField.getCell(x + 1, y) == EMPTY && gamer.gamerField.getCell(x + 1, y) != EMPTY){
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y, gamer);
                }
                if (mainField.getCell(x, y - 1) == EMPTY && gamer.gamerField.getCell(x, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y - 1, gamer);
                }
                if (mainField.getCell(x + 1, y - 1) == EMPTY && gamer.gamerField.getCell(x + 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y - 1, gamer);
                }
            }
            if (y != 0 && y != 9) {
                if (mainField.getCell(x, y + 1) == EMPTY && gamer.gamerField.getCell(x, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y + 1, gamer);
                }
                if (mainField.getCell(x, y - 1) == EMPTY && gamer.gamerField.getCell(x, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y - 1, gamer);
                }
                if (mainField.getCell(x + 1, y) == EMPTY && gamer.gamerField.getCell(x + 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y, gamer);
                }
                if (mainField.getCell(x + 1, y + 1) == EMPTY && gamer.gamerField.getCell(x + 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y + 1, EMPTY);
                   // scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y + 1, gamer);
                }
                if (mainField.getCell(x + 1, y - 1) == EMPTY && gamer.gamerField.getCell(x + 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y - 1, gamer);
                }
            }
        }
        if(x == 9){
            if(y == 0){
                if (mainField.getCell(x - 1, y) == EMPTY && gamer.gamerField.getCell(x - 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y, gamer);
                }
                if (mainField.getCell(x, y + 1) == EMPTY && gamer.gamerField.getCell(x, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y + 1, gamer);
                }
                if (mainField.getCell(x - 1, y + 1) == EMPTY && gamer.gamerField.getCell(x - 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y + 1, gamer);
                }
            }
            if(y == 9){
                if (mainField.getCell(x - 1, y) == EMPTY  && gamer.gamerField.getCell(x - 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y, gamer);
                }
                if (mainField.getCell(x, y - 1) == EMPTY && gamer.gamerField.getCell(x, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y - 1, gamer);
                }
                if (mainField.getCell(x - 1, y - 1) == EMPTY && gamer.gamerField.getCell(x - 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y - 1, gamer);
                }
            }
            if (y != 0 && y != 9) {
                if (mainField.getCell(x, y + 1) == EMPTY && gamer.gamerField.getCell(x, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y + 1, gamer);
                }
                if (mainField.getCell(x, y - 1) == EMPTY && gamer.gamerField.getCell(x, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y - 1, gamer);
                }
                if (mainField.getCell(x - 1, y + 1) == EMPTY && gamer.gamerField.getCell(x - 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y + 1, gamer);
                }
                if (mainField.getCell(x - 1, y - 1) == EMPTY && gamer.gamerField.getCell(x - 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y - 1, gamer);
                }
                if (mainField.getCell(x - 1, y) == EMPTY && gamer.gamerField.getCell(x - 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y, gamer);
                }
            }
        }
        if(x != 0 && x != 9){
            if(y == 0){
                if (mainField.getCell(x - 1, y) == EMPTY && gamer.gamerField.getCell(x - 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y, gamer);
                }
                if (mainField.getCell(x + 1, y) == EMPTY && gamer.gamerField.getCell(x + 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                   // scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y, gamer);
                }
                if (mainField.getCell(x, y + 1) == EMPTY && gamer.gamerField.getCell(x, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y + 1, EMPTY);
                   // scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y + 1, gamer);
                }
                if (mainField.getCell(x - 1, y + 1) == EMPTY && gamer.gamerField.getCell(x - 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y + 1, gamer);
                }
                if (mainField.getCell(x + 1, y + 1) == EMPTY && gamer.gamerField.getCell(x + 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y + 1, gamer);
                }
            }
            if(y == 9){
                if (mainField.getCell(x - 1, y) == EMPTY && gamer.gamerField.getCell(x - 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y, gamer);
                }
                if (mainField.getCell(x + 1, y) == EMPTY && gamer.gamerField.getCell(x + 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y, gamer);
                }
                if (mainField.getCell(x, y - 1) == EMPTY && gamer.gamerField.getCell(x, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y - 1, gamer);
                }
                if (mainField.getCell(x - 1, y - 1) == EMPTY && gamer.gamerField.getCell(x - 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y - 1, gamer);
                }
                if (mainField.getCell(x + 1, y - 1) == EMPTY && gamer.gamerField.getCell(x + 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y - 1, gamer);
                }
            }
            if (y != 0 && y != 9) {
                if (mainField.getCell(x, y + 1) == EMPTY && gamer.gamerField.getCell(x, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y + 1, gamer);
                }
                if (mainField.getCell(x, y - 1) == EMPTY && gamer.gamerField.getCell(x, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x, y - 1, gamer);
                }
                if (mainField.getCell(x - 1, y + 1) == EMPTY && gamer.gamerField.getCell(x - 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y + 1, gamer);
                }
                if (mainField.getCell(x - 1, y - 1) == EMPTY && gamer.gamerField.getCell(x - 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x - 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y - 1, gamer);
                }
                if (mainField.getCell(x - 1, y) == EMPTY && gamer.gamerField.getCell(x - 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x - 1, y, gamer);
                }
                if (mainField.getCell(x + 1, y) == EMPTY && gamer.gamerField.getCell(x + 1, y) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y, gamer);
                }
                if (mainField.getCell(x + 1, y - 1) == EMPTY && gamer.gamerField.getCell(x + 1, y - 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y - 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y - 1, gamer);
                }
                if (mainField.getCell(x + 1, y + 1) == EMPTY && gamer.gamerField.getCell(x + 1, y + 1) != EMPTY) {
                    gamer.openedCells++;
                    gamer.gamerField.setCell(x + 1, y + 1, EMPTY);
                    //scoreForEmptyCells += 100;
                    gamer.gamerScore += 100;
                    setEmptyCells(x + 1, y + 1, gamer);
                }
            }
        }
    }
    private void executeDesire(Mode desire, GameView view){
        if (desire == Mode.NEW_GAME) {
            new_game = true;
            return;
        }
        if (desire == Mode.EXIT) {
            exit = true;
            return;
        }
        if (desire == Mode.ABOUT){
            view.printReference();
            return;
        }
        if (desire == Mode.HIGH_SCORES){
            view.printHighScores();
            return;
        }
    }
    public void run(int mode) throws IOException {
        new_game = true;        //чтобы хоть раз зайти в цикл
        while (new_game) {
            new_game = false;           //если пользователь не введет new_game игра не будет исполняться
            //создаем gameView
            GameView view = null;
            if (mode == 0) view = new ConsoleView();
            //инициализируем поле рефери (оно недоступно игроку)
            mainField = new Field(10);
            fillField();
            view.drawField(mainField);//для отладки
            //создаем обработчик комманд пользователя
            Command askUser = new ConsoleCommands();
            //создаем игрока
            ConsoleGamer gamer = new ConsoleGamer(askUser.getName());
            //выводим все известное об игроке
            view.printName(gamer.gamerName);
            view.printScore(gamer.gamerScore);
            view.drawField(gamer.gamerField);
            //основная работа - игра
            while (!gameOver) {
                int x, y;           //координаты, введенные пользователем
                Mode desire;      //что пользователь хочет сделать
                //узнаем x, y, desire
                askUser.getDesireAndCoordinates();
                x = askUser.getX();
                y = askUser.getY();
                desire = askUser.getDesire();
                //если ввели не open/flag (то что не требует координат)
                if (desire != Mode.OPEN && desire != Mode.FLAG) {
                    executeDesire(desire, view);
                    if (exit) return;
                    if (new_game) break;
                }
                else {
                    Cell localCell = mainField.getCell(x, y);      //клетка в поле mainField
                    //пока пользователь хочет открыть или поставить флаг на уже открытую клетку, просим ввести корректные координаты
                    while (desire == Mode.OPEN && gamer.gamerField.getCell(x, y) != UNKNOWN && gamer.gamerField.getCell(x, y) != FLAG || desire == Mode.FLAG && gamer.gamerField.getCell(x, y) != UNKNOWN) {
                        askUser.getDesireAndCoordinates();   //узнаем x, y, desire
                        x = askUser.getX();
                        y = askUser.getY();
                        desire = askUser.getDesire();
                        //если ввели не open/flag
                        if (desire != Mode.OPEN && desire != Mode.FLAG) {
                            executeDesire(desire, view);
                            if (exit) return;
                            if (new_game) break;
                        }
                    }
                    //если пользователь решил открыть клетку
                    if (desire == Mode.OPEN) {
                        //если BOMB, то игра окончена
                        if (localCell == BOMB) {
                            gamer.openedCells++;
                            gamer.gamerField.setCell(x, y, BOMB);
                            gameOver = true;
                        }
                        //если цифра, то просто устанавливаем ее на поле игрока
                        if (localCell == ONE || localCell == TWO || localCell == THREE || localCell == FOUR || localCell == FIVE) {
                            gamer.openedCells++;
                            gamer.gamerField.setCell(x, y, localCell);
                            gamer.gamerScore += 100;
                        }
                        //если пустая, то открываем все пустые вокруг нее
                        if (localCell == EMPTY) {
                            gamer.openedCells++;
                            gamer.gamerField.setCell(x, y, EMPTY);
                            gamer.gamerScore += 100;
                            setEmptyCells(x, y, gamer);//рекурсивная функция для открытия всех пустых клеток, которые связаны с пустой клеткой, которую открыл пользователь
                        }
                    }
                    //если пользователь решил поставить флаг
                    if (desire == Mode.FLAG) {
                        gamer.gamerField.setCell(x, y, FLAG);
                    }
                }
                view.printName(gamer.gamerName);
                view.printScore(gamer.gamerScore);
                view.drawField(gamer.gamerField);
                if (gamer.openedCells == 95){
                    gameOver = true;
                    view.printWinner();
                }
                if (gameOver){
                    if (askUser.getInf()) new_game = true;
                    else{
                        view.saveScore(gamer.gamerName, gamer.gamerScore);
                        return;
                    }
                }
            }
        }
    }
}
