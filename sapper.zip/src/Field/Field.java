package Field;

import java.util.HashMap;
import java.util.Map;

public class Field {
    private Map<Integer, Cell> field;
    private int size;
    public Field(int size) {
        this.size = size;
        field = new HashMap<Integer, Cell>();
        for (int i = 0; i < size * size; i++){
            field.put(i, Cell.UNKNOWN);
        }
    }       //создаем поле для игры размером size*size
    public Cell getCell(int x, int y){
        int coordinate = y * size + x;                   //проверить так ли написала!!!
        return field.get(coordinate);
    }
    public void setCell(int x, int y, Cell value){
        int coordinate = y  * size + x;                   //проверить так ли написала!!!
        field.put(coordinate, value);
    }
}
