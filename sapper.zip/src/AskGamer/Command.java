package AskGamer;

import Controller.Mode;

public interface Command {
    public void getDesireAndCoordinates();
    public boolean getInf();
    public int getX();
    public int getY();
    public Mode getDesire();
    public String getName();
}
