import Controller.GameController;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        GameController game = new GameController();
        game.run(0);
    }
}
