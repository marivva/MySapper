import Model.Executer.someWork;
import View.BaseWindow;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        int GameMode = 1;
        if (GameMode == 0) {        //консольная игра
            someWork game = new someWork();
            game.run();
        }
        else                        //неконсольная игра
            new BaseWindow();       //создаем главное окно
    }
}
