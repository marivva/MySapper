package MyTimer;

import View.BaseWindow;

import javax.swing.*;
import java.awt.*;

public class PrintTime {
    public JTextArea bDecMin = new JTextArea("0");
    public JTextArea bMin = new JTextArea("0");
    public JTextArea bDecSec = new JTextArea("0");
    public JTextArea bSec = new JTextArea("0");
    public JTextArea bSplit = new JTextArea(":");
    public PrintTime(BaseWindow baseWindow, Container container, GridBagConstraints constraints) throws InterruptedException {
        bDecMin.setFont(new Font("Dialog", Font.PLAIN, 30));
        bMin.setFont(new Font("Dialog", Font.PLAIN, 30));
        bDecSec.setFont(new Font("Dialog", Font.PLAIN, 30));
        bSec.setFont(new Font("Dialog", Font.PLAIN, 30));
        bSplit.setFont(new Font("Dialog", Font.PLAIN, 30));
        container.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        constraints.gridy = 10;
        constraints.gridx = 3;
        container.add(bDecMin, constraints);
        constraints.gridx = 4;
        container.add(bMin, constraints);
        constraints.gridx = 5;
        container.add(bSplit, constraints);
        constraints.gridx = 6;
        container.add(bDecSec, constraints);
        constraints.gridx = 7;
        container.add(bSec, constraints);
        baseWindow.MyWindow.setVisible(true);
    }
    public void ReTime(BaseWindow baseWindow, int InSec){
        int min = 0;
        int decMin = 0;
        int sec = InSec;
        int decSec = 0;
        while (sec > 9){
            sec = sec-10;
            decSec++;
            if(decSec > 5){
                decSec = decSec - 6;
                min++;
                if(min > 9){
                    min = min-10;
                    decMin++;
                }
            }
        }
        bDecMin.setText("" + decMin);
        bMin.setText("" + min);
        bDecSec.setText("" + decSec);
        bSec.setText("" + sec);
        baseWindow.MyWindow.repaint();
    }
}
