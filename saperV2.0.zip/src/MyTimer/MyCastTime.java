package MyTimer;

import java.util.TimerTask;

public class MyCastTime {
    public static int seconds = 0;
    private static int milliseconds = 0;
    private static Runnable runnable;
    private static TimerTask task;
    private static java.util.Timer timer;
    private static boolean running = false;
    public static boolean stop = false;
    private static void createTask() {
        task = new TimerTask()
        {
            @Override
            public void run()
            {
                milliseconds++;
                seconds += milliseconds / 10;
                if (seconds + milliseconds / 10 > seconds) runnable.run();
                milliseconds %= 10;
            }
        };
        timer = new java.util.Timer();
    }
    private static void schedule() {
        timer.schedule(task,0,100);
    }
    public static void start(Runnable run) {
        if (running) return;
        milliseconds = 0;
        seconds = 0;
        runnable = run;
        running = true;
        createTask();
        schedule();
    }
    public static void stop() {
        if (timer == null || !running) return;
        running = false;
        timer.cancel();
        timer.purge();
    }
}
