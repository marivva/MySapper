package View;

import Model.Field.Buttons;
import Model.Field.Field;
import MyTimer.PrintTime;

import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class GraphicView implements GameView {
    @Override
    public void drawField(Field field, String name, int score, BaseWindow base, Buttons buttons) throws InterruptedException {
        Container container= base.MyWindow.getContentPane();
        container.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        container.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.CENTER;
        for (int i = 0; i < 10; i++){
            for (int j = 0; j < 10; j++){
                constraints.gridy = i;
                constraints.gridx = j;
                container.add(buttons.buttons[i + 10 * j], constraints);
            }
        }
        if (!base.myCastTime.stop) {        //(после нажатия NewGame) запускаем таймер и начинаем его печатать
            PrintTime printTime = new PrintTime(base, container, constraints);
            base.MyWindow.setVisible(true);
            base.myCastTime.start(() -> {
                printTime.ReTime(base, base.myCastTime.seconds);
            });
        }
        else {                              //(после выигрыша/проигрыша печатаем 00:00)
            new PrintTime(base, container, constraints);
            base.MyWindow.setVisible(true);
        }
    }
    public Map <String, Integer> sortByValue(Map<String, Integer> words){
        List<Map.Entry<String, Integer>> list = new ArrayList(words.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });
        //Collections.reverse(list);
        Map<String, Integer> sortedMap = new LinkedHashMap();
        for(Map.Entry<String, Integer> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }
    @Override
    public void saveScore(String name, int score) throws IOException {
        Map<String, Integer> previousScores = new HashMap<>();
        File file = new File("src/score.txt");
        Scanner scanner = new Scanner(file);
        while(scanner.hasNextLine()){
            String tmp = scanner.nextLine();
            String[] words = tmp.split(" ");
            previousScores.put(words[0], Integer.parseInt(words[1]));
        }
        previousScores.put(name, score);
        //previousScores.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed());
        previousScores = sortByValue(previousScores);
        FileWriter wr = new FileWriter(file);
        int count = 0;
        for (Map.Entry<String, Integer> entry: previousScores.entrySet()){
            count++;
            wr.write(entry.getKey().toString() + ' ' + entry.getValue().toString());
            wr.append('\n');
            if(count >= 20) {
                wr.close();
                break;
            }
        }
        wr.close();
    }
    @Override
    public void printReference(){
        return;
    }
    @Override
    public void printHighScores(){ return; }
    @Override
    public void printWinner(){ return; }
    @Override
    public void printLoser(){ return; }
}
