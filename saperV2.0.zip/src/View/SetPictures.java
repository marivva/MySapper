package View;

import Model.Field.Cell;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.IOException;

public class SetPictures {
    public void setPicture(JButton button, Cell mode) throws IOException {
        switch (mode){
            case BOMB: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/bomb.png")))); break;
            case EMPTY: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/empty.png")))); break;
            case UNKNOWN: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/unknown.png")))); break;
            case FLAG: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/flag.png")))); break;
            case ONE: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/one.png")))); break;
            case TWO: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/two.png")))); break;
            case THREE: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/three.png")))); break;
            case FOUR: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/four.png")))); break;
            case FIVE: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/five.png")))); break;
            case SIX: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/six.png")))); break;
            case SEVEN: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/seven.png")))); break;
            case EIGHT: button.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/pictures/eight.png")))); break;
        }
    }
}
