package View;

import Model.Field.Buttons;
import Model.Field.Field;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class ConsoleView implements GameView {
    @Override
    public void drawField(Field field, String name, int score, BaseWindow base, Buttons buttons){
        System.out.print(name + ' ');
        System.out.println("SCORE: " + Integer.toString(score));
        System.out.print("   0 1 2 3 4 5 6 7 8 9\n");
        for (int i = 0; i < 10; i++) {
            System.out.print(Integer.toString(i) +' ' + "|");
            for (int j = 0; j < 10; j++) {
                String c = null;
                switch (field.getCell(j, i)){
                    case UNKNOWN: c = "_"; break;
                    case EMPTY: c = " "; break;
                    case FLAG: c = "F"; break;
                    case BOMB: c = "B"; break;
                    case ONE: c = "1"; break;
                    case TWO: c = "2"; break;
                    case THREE: c = "3"; break;
                    case FOUR: c = "4"; break;
                    case FIVE: c = "5"; break;
                }
                System.out.print(c + '|');
            }
            System.out.print("\n");
        }
    }
    @Override
    public void printReference(){
        System.out.println(">>REFERENCE:");
        System.out.println("Abbreviations");
        System.out.println("F - flag");
        System.out.println(" _");
        System.out.println("|_| - unopened cell");
        System.out.println("B - bomb");
        System.out.println("1/2/3/4/5 - count of bombs around this cell");
        System.out.println("Available commands");
        System.out.println("new game - for start new game");
        System.out.println("about - for REFERENCE");
        System.out.println("high scores - for print high scores");
        System.out.println("exit - for exit from app");
    }
    @Override
    public void printHighScores(){            //?????????????/
        System.out.println("High scores:");
        Scanner scanner = new Scanner("scores.txt");
        System.out.println(scanner.nextLine());
    }
    public Map <String, Integer> sortByValue(Map<String, Integer> words){
        List<Map.Entry<String, Integer>> list = new ArrayList(words.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });
        //Collections.reverse(list);
        Map<String, Integer> sortedMap = new LinkedHashMap();
        for(Map.Entry<String, Integer> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }
    @Override
    public void saveScore(String name, int score) throws IOException {
        Map<String, Integer> previousScores = new HashMap<>();
        File file = new File("src/score.txt");
        Scanner scanner = new Scanner(file);
        while(scanner.hasNextLine()){
            String tmp = scanner.nextLine();
            String[] words = tmp.split(" ");
            previousScores.put(words[0], Integer.parseInt(words[1]));
        }
        previousScores.put(name, score);
        //previousScores.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed());
        previousScores = sortByValue(previousScores);
        FileWriter wr = new FileWriter(file);
        int count = 0;
        for (Map.Entry<String, Integer> entry: previousScores.entrySet()){
            count++;
            wr.write(entry.getKey().toString() + ' ' + entry.getValue().toString());
            wr.append('\n');
            if(count >= 100) break;
        }
        wr.close();
    }
    @Override
    public void printWinner(){
        System.out.println("Congratulations, you WIN!!!");
    }
    @Override
    public void printLoser(){
        System.out.println("Sorry, you LOSE!!!");
    }
}
