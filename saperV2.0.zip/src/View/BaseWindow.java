package View;

import Model.Executer.Mode;
import View.Menu.MyMenuBar;
import MyTimer.MyCastTime;

import javax.swing.*;
import java.awt.*;

public class BaseWindow {
    public Mode exit;
    public Mode newgame;
    public JFrame MyWindow = new JFrame();
    public SetPictures setPictures = new SetPictures();
    public MyCastTime myCastTime = new MyCastTime();
    private void AddMenuToWindow(){
        JMenuBar menuBar=new JMenuBar();
        JMenuItem NewGame=new JMenuItem();
        JMenuItem exit=new JMenuItem();
        JMenuItem about=new JMenuItem();
        JMenuItem HighScore=new JMenuItem();
        HighScore.setText("High Scores");
        about.setText("About");
        exit.setText("Exit");
        NewGame.setText("New game");
        menuBar.add(NewGame);
        menuBar.add(HighScore);
        menuBar.add(about);
        menuBar.add(exit);
        MyWindow.setJMenuBar(menuBar);
        new MyMenuBar(NewGame, exit, about, HighScore, this);   //добавляем действия при нажатии на кнопку
    }
    public BaseWindow() {
        MyWindow.setSize(1200, 750);
        MyWindow.setLocationRelativeTo(null);
        MyWindow.setLayout(new GridBagLayout());
        MyWindow.setTitle("GAME");
        exit = Mode.UNKNOWN;
        newgame = Mode.UNKNOWN;
        AddMenuToWindow();              //Добавляем кнопки меню
        if (newgame == Mode.UNKNOWN)
            MyWindow.setVisible(true);
    }
    public void DeleteAll(){
        MyWindow.getContentPane().removeAll();
        MyWindow.repaint();
    }
}