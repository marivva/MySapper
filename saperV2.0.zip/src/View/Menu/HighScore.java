package View.Menu;

import View.BaseWindow;

import javax.swing.*;
import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class HighScore {
    public HighScore(BaseWindow baseWindow) {
        //после сохранения результата пользователя, при нажатии на кнопку High Score в меню, этот результат не будет отображаться,
        //но в файле score.txt он сохранится и при перезапуске игры отобразится
        Scanner MyScan = null;
        try {
            MyScan = new Scanner(new FileInputStream("out/production/lab3saperrr/score.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        baseWindow.DeleteAll();
        String myString;
        JTextArea table[] = new JTextArea[10];
        Container container = baseWindow.MyWindow.getContentPane();
        container.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        container.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.CENTER;
        constraints.gridy = 0;
        constraints.gridx = 0;
        int i = 0;
        while (MyScan.hasNextLine() && i != 10) {       //выводятся только первые 10 позиций
            myString = MyScan.nextLine();
            table[i] = new JTextArea(myString);
            constraints.gridy = i;
            table[i].setFont(new Font("Dialog", Font.PLAIN, 30));
            container.add(table[i], constraints);
            i++;
        }
        baseWindow.MyWindow.setVisible(true);
    }
}