package View.Menu;

import Controller.ControlForGraphicField;
import Model.Executer.Mode;
import MyTimer.MyCastTime;
import View.BaseWindow;

import javax.swing.*;
import java.io.IOException;

public class MyMenuBar {
    public MyMenuBar(JMenuItem NewGame, JMenuItem exit, JMenuItem about, JMenuItem HighScore, BaseWindow baseWindow) {
        exit.addActionListener((e) -> {
            baseWindow.MyWindow.setVisible(false);
            baseWindow.exit = Mode.EXIT;
            return;
        });
        about.addActionListener((e) -> {
            baseWindow.DeleteAll();
            try {
                About a = new About(baseWindow);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            baseWindow.MyWindow.setVisible(true);
        });
        HighScore.addActionListener((e -> {
            baseWindow.DeleteAll();
            HighScore hs = new HighScore(baseWindow);
            baseWindow.MyWindow.setVisible(true);
        }));
        NewGame.addActionListener((e -> {
            baseWindow.DeleteAll();
            baseWindow.newgame = Mode.NEW_GAME;
            try {
                new ControlForGraphicField(baseWindow);     //начинаем игру
            } catch (IOException | InterruptedException ex) {
                ex.printStackTrace();
            }
        } ));
    }
}
