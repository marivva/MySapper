package View.Menu;

import Model.Field.Cell;
import View.BaseWindow;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class About {
    public About(BaseWindow baseWindow) throws IOException {
        Container container= baseWindow.MyWindow.getContentPane();
        container.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        container.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.WEST;

        constraints.gridy = 0;                          //пример пустой клетки
        constraints.gridx = 0;
        JButton empty = new JButton("");
        baseWindow.setPictures.setPicture(empty, Cell.EMPTY);
        JTextArea emptyRef = new JTextArea("This is example of empty open cell");
        container.add(empty, constraints);
        constraints.gridx = 5;
        emptyRef.setFont(new Font("Dialog", Font.PLAIN, 30));
        container.add(emptyRef, constraints);
        constraints.gridy = 1;

        JButton one = new JButton("");              //пример клеток с цифрами
        JButton two = new JButton("");
        JButton three = new JButton("");
        JButton four = new JButton("");
        baseWindow.setPictures.setPicture(one,Cell.ONE);
        baseWindow.setPictures.setPicture(two, Cell.TWO);
        baseWindow.setPictures.setPicture(three,Cell.THREE);
        baseWindow.setPictures.setPicture(four,Cell.FOUR);
        JTextArea numRef = new JTextArea("This is example of number cells");
        numRef.setFont(new Font("Dialog", Font.PLAIN, 30));
        constraints.gridx = 0;
        container.add(one, constraints);
        constraints.gridx = 1;
        container.add(two, constraints);
        constraints.gridx = 2;
        container.add(three, constraints);
        constraints.gridx = 3;
        container.add(four, constraints);
        constraints.gridx = 5;
        container.add(numRef, constraints);
        constraints.gridy = 2;

        JButton unknown = new JButton("");               //пример ненажатой кнопки
        baseWindow.setPictures.setPicture(unknown,Cell.UNKNOWN);
        JTextArea unknownRef = new JTextArea("This is example of not opened cell");
        unknownRef.setFont(new Font("Dialog", Font.PLAIN, 30));
        constraints.gridx = 0;
        container.add(unknown, constraints);
        constraints.gridx = 5;
        container.add(unknownRef, constraints);
        constraints.gridy = 3;

        JButton flag = new JButton("");                 //пример кнопки с флагом
        baseWindow.setPictures.setPicture(flag,Cell.FLAG);
        JTextArea flagRef =new JTextArea("This is example of cell with flag");
        flagRef.setFont(new Font("Dialog", Font.PLAIN, 30));
        constraints.gridx = 0;
        container.add(flag, constraints);
        constraints.gridx = 5;
        container.add(flagRef, constraints);
        constraints.gridy = 4;

        JButton bomb = new JButton("");                 //пример кнопки с бомбой
        baseWindow.setPictures.setPicture(bomb,Cell.BOMB);
        JTextArea bombRef =new JTextArea("This is example of cell with bomb");
        bombRef.setFont(new Font("Dialog", Font.PLAIN, 30));
        constraints.gridx = 0;
        container.add(bomb, constraints);
        constraints.gridx = 5;
        container.add(bombRef, constraints);
    }
}
