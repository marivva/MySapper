package View;

import Model.Field.Buttons;
import Model.Field.Field;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public interface GameView {
    public void drawField(Field field, String name, int score, BaseWindow base, Buttons buttons) throws InterruptedException;
    public  void printReference();
    public void printHighScores();
    public void saveScore(String name, int score) throws IOException;
    public void printWinner();
    public void printLoser();
}
