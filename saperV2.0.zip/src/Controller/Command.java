package Controller;

import Model.Executer.Mode;
import Model.Field.Field;

public interface Command {
    public void getDesireAndCoordinates(Field field);
    public boolean getInf();
    public void getName();
    public UserDataIn getData();
}
