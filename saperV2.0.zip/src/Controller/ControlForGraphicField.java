package Controller;

import Model.Executer.Mode;
import Model.Field.Buttons;
import Model.Field.Cell;
import Model.Field.Field;
import MyTimer.MyCastTime;
import MyTimer.PrintTime;
import View.BaseWindow;
import View.GameView;
import View.GraphicView;

import java.io.IOException;

public class ControlForGraphicField {
    public Buttons buttons;
    Field mainField;
    Field gamerField;
    BaseWindow baseWindow;
    int gameover = 0;
    public ControlForGraphicField(BaseWindow baseWindow) throws IOException, InterruptedException {
        this.baseWindow = baseWindow;
        buttons = new Buttons(this.baseWindow);         //создаем массив клеток-кнопок
        mainField = new Field(10);
        mainField.fillField();                          //расставляем мины, цифры, пустые клетки на главном поле(недоступном игроку)
        gamerField = new Field(10);
        baseWindow.myCastTime.stop = false;
        GameView view = new GraphicView();
        view.drawField(gamerField, null, 0, baseWindow, buttons);   //рисуем начальное поле игрока(все клетки UNKNOWN), запускаем таймер
        baseWindow.MyWindow.setVisible(true);
        new ForWindowB(this);       //добавляем клеткам-кнопкам действия, при нажатии на них
    }
    public boolean checkEnd(){
        if (gameover == 1) return true;
        else return false;
    }
    public void setCell(int x, int y, Mode desire) throws IOException, InterruptedException {
        UserDataIn dataIn = new UserDataIn();
        dataIn.x = x;
        dataIn.y = y;
        dataIn.desire = desire;
        gamerField.execCell(dataIn, mainField.getCell(x, y), mainField);    //исполняем действие (с полем клеток), введенное пользователем
        dataIn.score = gamerField.openedCells * 100;
        buttons.fillButtons(dataIn.field, baseWindow);      //копируем информацию об изменении поля клеток в поле кнопок
        baseWindow.MyWindow.setVisible(true);
        if (gamerField.checkWin() || gamerField.checkLose()){   //проверяем не закончилась ли игра, если - да, то:
            baseWindow.myCastTime.stop = true;
            baseWindow.myCastTime.stop();      //останавливаем таймер
            gameover = 1;
            if (gamerField.checkWin()) dataIn.win = 1;
            if (gamerField.checkLose()) dataIn.lose = 1;
            endGame(dataIn, buttons);          //запускаем процедуру конца игры
        }
    }
    public void endGame(UserDataIn dataIn, Buttons buttons) throws IOException, InterruptedException {
        baseWindow.DeleteAll();
        buttons.fillButtons(mainField, baseWindow);     //копируем в поле кнопок информацию из главного поля(чтобы вывести его на экран)
        GameView view = new GraphicView();
        view.drawField(mainField, null, 0, baseWindow, buttons);    //рисуем поле клеток-кнопок
        new GameOver(baseWindow, dataIn, buttons);      //создание нового диалогового окна для информирования о результатах игры
    }
}
