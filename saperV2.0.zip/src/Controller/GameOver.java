package Controller;

import Model.Field.Buttons;
import View.BaseWindow;
import View.GameView;

import javax.swing.*;
import java.awt.*;

public class GameOver extends JFrame {
    public GameOver(BaseWindow baseWindow, UserDataIn dataIn, Buttons buttons){
        super("Game Over");
        this.setSize(500, 300);
        this.setLocationRelativeTo(null);
        this.setLayout(new GridBagLayout());
        Container container = this.getContentPane();
        container.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        container.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridy = 0  ;
        constraints.gridx = 0;
        constraints.weighty = 1.0;
        JTextArea text = new JTextArea();
        JButton button = new JButton("OK");
        if (dataIn.win == 1) {             //если выигрыш
            text.setText("Congratulations, you win!");
            button.addActionListener(e -> {         //при нажатии на кнопку OK, пользователя попросят ввести имя, для сохранения его результата
                new GetGamerName(this, baseWindow, dataIn);
            });
        }
        else {                          //если проигрыш
            text.setText("Sorry, you lose. Try again.");
            button.addActionListener(e -> {         //при нажатии на кнопку OK, окно закроется и можно работать дальше
                this.setVisible(false);
            });
        }
        text.setFont(new Font("Dialog", Font.PLAIN, 20));
        container.add(text, constraints);
        constraints.gridy = 1;
        constraints.gridx = 0;
        container.add(button, constraints);
        this.setVisible(true);
    }
}
