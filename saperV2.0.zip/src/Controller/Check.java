package Controller;

import Model.Executer.Mode;

public class Check {
    public boolean checkNewGame(Mode mode){
        if (mode == Mode.NEW_GAME) return true;
        else return false;
    }
    public boolean checkExit(Mode mode){
        if (mode == Mode.EXIT) return true;
        else return false;
    }
    public boolean checkWin(int count){
        if (count >= 90) return true;
        else return false;
    }
}
