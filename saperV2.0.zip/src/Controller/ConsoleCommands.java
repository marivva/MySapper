package Controller;

import Model.Executer.Mode;
import Model.Field.Field;

import java.util.Scanner;

import static Model.Field.Cell.FLAG;
import static Model.Field.Cell.UNKNOWN;

public class ConsoleCommands implements Command {
    private UserDataIn data;
    public ConsoleCommands(){
        data = new UserDataIn();
    }
    @Override
    public void getDesireAndCoordinates(Field field) {
        Scanner scan = new Scanner(System.in);
        //узнаем что пользовтель хочет сделать с клеткой, пока не введут корректное значение
        boolean correct = false;
        while (!correct) {
            System.out.println(">>Enter what you want (open cell/make flag/new game/about/exit/high scores): ");
            String modeStr = scan.nextLine();
            if (modeStr.compareTo("open cell") == 0) {
                correct = true;
                data.desire = Mode.OPEN;
            }
            if (modeStr.compareTo("make flag") == 0) {
                data.desire = Mode.FLAG;
                correct = true;
            }
            if (modeStr.compareTo("new game") == 0) {
                data.desire = Mode.NEW_GAME;
                correct = true;
            }
            if (modeStr.compareTo("about") == 0) {
                data.desire = Mode.ABOUT;
                correct = true;
            }
            if (modeStr.compareTo("exit") == 0) {
                data.desire = Mode.EXIT;
                correct = true;
            }
            if (modeStr.compareTo("high scores") == 0) {
                data.desire = Mode.HIGH_SCORES;
                correct = true;
            }
        }
        //если ввели открыть/поставить флаг, то спрашиваем координаты
        if (data.desire == Mode.OPEN || data.desire == Mode.FLAG) {
            //спрашивем координаты, пока они не окажутся корректными
            data.x = -1;
            data.y = -1;
            while (data.x == -1 || data.y == -1 || data.desire == Mode.OPEN && field.getCell(data.x, data.y) != UNKNOWN && field.getCell(data.x, data.y) != FLAG || data.desire == Mode.FLAG && field.getCell(data.x, data.y) != UNKNOWN) {
                System.out.println(">>Enter x coordinate: ");
                int userX = scan.nextInt();
                System.out.println(">>Enter y coordinate: ");
                int userY = scan.nextInt();
                if (userX >= 0 && userX <= 9 && userY >= 0 && userY <= 9) {
                    data.x = userX;
                    data.y = userY;
                }
            }
        }
    }
    @Override
    public boolean getInf(){
        System.out.println(">>Do you want play new game?(yes/no)");
        Scanner scanner = new Scanner(System.in);
        String answer = scanner.nextLine();
        boolean correct = false;
        if(answer.compareTo("yes") == 0 || answer.compareTo("no") == 0) correct = true;
        else
            while (answer.compareTo("yes") != 0 || answer.compareTo("no") != 0) {
                System.out.println(">>Do you want play new game?(yes/no)");
                answer = scanner.nextLine();
            }
        if (answer.compareTo("yes") == 0) return true;
        else return false;
    }
    @Override
    public void getName(){
        System.out.println("Enter your name (without spaces):");
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        data.name = name;
    }
    @Override
    public UserDataIn getData(){
        return data;
    }
}
