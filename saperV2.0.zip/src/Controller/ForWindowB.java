package Controller;

import Model.Executer.Mode;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class ForWindowB {
    public ForWindowB(ControlForGraphicField control){
        for( int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                int x = i;
                int y = j;
                control.buttons.buttons[i + 10 * j].addMouseListener(new MouseAdapter() {
                    public void mousePressed(MouseEvent me) {
                        if (!control.checkEnd()) {
                            if (SwingUtilities.isLeftMouseButton(me)) {     //нажатие левой кнопкой мыши - open
                                try {
                                    control.setCell(x, y, Mode.OPEN);
                                } catch (IOException | InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            if (SwingUtilities.isRightMouseButton(me)) {    //нажатие правой кнопкой мыши - flag
                                try {
                                    control.setCell(x, y, Mode.FLAG);
                                } catch (IOException | InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                });
            }
        }
    }
}
