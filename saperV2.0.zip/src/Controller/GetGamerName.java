package Controller;

import View.BaseWindow;
import View.GameView;
import View.GraphicView;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class GetGamerName {
    public GetGamerName(JFrame frame, BaseWindow baseWindow, UserDataIn dataIn) {
        frame.getContentPane().removeAll();
        frame.repaint();
        JTextField name = new JTextField("Enter your name...                   ");
        JButton enter = new JButton("ENTER");
        Container container = frame.getContentPane();
        container.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        container.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.CENTER;
        constraints.gridy = 0;
        constraints.gridx = 0;
        enter.addActionListener(e -> {          //после того, как пользователь введет имя и нажмет на кнопку ENTER
            String gamerName = null;
            gamerName = name.getText();
            String[] wordsInName = gamerName.split(" ");        //берем только первое слово имени
            gamerName = wordsInName[0];
            GameView save = new GraphicView();
            try {
                save.saveScore(gamerName, dataIn.score);                //сохраняем результат в файле score.txt
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            frame.setVisible(false);
        });
        container.add(name, constraints);
        constraints.gridy = 1 ;
        container.add(enter, constraints);
        frame.setVisible(true);
    }
}
