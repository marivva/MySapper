package Controller;

import Model.Executer.Mode;
import Model.Field.Field;

public class UserDataIn {
    public int x;
    public int y;
    public Mode desire;
    public String name;
    public Field field;
    public int openedCells;
    public int win = 0;
    public int lose = 0;
    public int score = 0;
    public UserDataIn(){
        x = 0;
        y = 0;
        desire = Mode.UNKNOWN;
        field = new Field(10);
        openedCells = 0;
    }
}
