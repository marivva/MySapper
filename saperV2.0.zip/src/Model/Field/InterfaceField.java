package Model.Field;

public interface InterfaceField {

}
