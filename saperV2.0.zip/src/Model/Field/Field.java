package Model.Field;

import Controller.UserDataIn;
import Model.Executer.Mode;
import Model.Gamer.Gamer;
import View.BaseWindow;

import java.io.IOException;

import static Model.Field.Cell.*;

public class Field {
    private Cell[] field;
    private int size;
    public int openedCells = 0;
    public int win = 0;
    public int lose = 0;
    public Field(int size) {
        this.size = size;
        field = new Cell[size * size];
        for (int i = 0; i < size * size; i++){
            field[i] = Cell.UNKNOWN;
        }
    }       //создаем поле для игры размером size*size
    public Cell getCell(int x, int y){
        int coordinate = y * size + x;
        return field[coordinate];
    }
    public void setCell(int x, int y, Cell value){
        int coordinate = y  * size + x;
        field[coordinate] = value;
    }
    private void check_cells_around(int x, int y){
        switch (this.getCell(x, y)){
            case UNKNOWN: this.setCell(x, y, Cell.ONE); break;
            case ONE: this.setCell(x, y, Cell.TWO); break;
            case TWO: this.setCell(x, y, Cell.THREE); break;
            case THREE: this.setCell(x, y, Cell.FOUR); break;
            case FOUR: this.setCell(x, y, Cell.FIVE); break;
            case FIVE: this.setCell(x, y, SIX); break;
            case SIX: this.setCell(x, y, SEVEN); break;
            case SEVEN: this.setCell(x, y, EIGHT); break;
        }
    }
    public void fillField(){
        int max = 10;
        int[] Xcoordinates = new int[10];
        int[] Ycootdinates = new int[10];
        int countFilledCells = 10;
        //устанавливаем на поле 5 бомб на произвольные позиции
        for(int i = 0; i < 10; i++){
            int x = (int)(Math.random() * max);
            int y = (int)(Math.random() * max);
            while(this.getCell(x, y) != UNKNOWN){
                x = (int)(Math.random() * max);
                y = (int)(Math.random() * max);
            }
            Xcoordinates[i] = x;
            Ycootdinates[i] = y;
            this.setCell(x, y, Cell.BOMB);
        }
        //заполняем клетки с цифрами
        for(int i = 0; i < 10; i++) {
            if(Xcoordinates[i] == 0){
                if(Ycootdinates[i] == 0){
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    countFilledCells += 3;
                }
                if(Ycootdinates[i] == 9){
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    countFilledCells += 3;
                }
                if (Ycootdinates[i] != 0 && Ycootdinates[i] != 9) {
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    countFilledCells += 5;
                }
            }
            if(Xcoordinates[i] == 9){
                if(Ycootdinates[i] == 0){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    countFilledCells += 3;
                }
                if(Ycootdinates[i] == 9){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    countFilledCells += 3;
                }
                if (Ycootdinates[i] != 0 && Ycootdinates[i] != 9) {
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    countFilledCells += 5;
                }
            }
            if(Xcoordinates[i] != 0 && Xcoordinates[i] != 9){
                if(Ycootdinates[i] == 0){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    countFilledCells += 5;
                }
                if(Ycootdinates[i] == 9){
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    countFilledCells += 5;
                }
                if (Ycootdinates[i] != 0 && Ycootdinates[i] != 9) {
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i], Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] + 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] - 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i]);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] - 1);
                    check_cells_around(Xcoordinates[i] + 1, Ycootdinates[i] + 1);
                    countFilledCells += 8;
                }
            }
        }
        int remains = 100 - countFilledCells;
        //заполняем оставшиеся клетки пустыми значениями
        for(int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (this.getCell(i, j) == UNKNOWN) this.setCell(i, j, EMPTY);
            }
        }
    }
    private void check_empty(int x, int y, UserDataIn data, Field mainField) {
        if (mainField.getCell(x, y) == EMPTY && data.field.getCell(x, y) != EMPTY){
            data.openedCells++;
            data.field.setCell(x, y, EMPTY);
            //data.score += 100;
            openedCells++;
            //if (openedCells >= 90)
            //  checkWin(data, mainField);
            if (openedCells == 90) win = 1;
            setEmptyCells(x, y, data, mainField);
        }
    }
    private void setEmptyCells(int x, int y, UserDataIn data, Field mainField) {
        if(x == 0){
            if(y == 0){
                check_empty(x + 1, y, data, mainField);
                check_empty(x, y + 1, data, mainField);
                //check_empty(x + 1, y + 1, data, mainField);
            }
            if(y == 9){
                check_empty(x + 1, y, data, mainField);
                check_empty(x, y - 1, data, mainField);
                //check_empty(x + 1, y - 1, data, mainField);
            }
            if (y != 0 && y != 9) {
                check_empty(x, y + 1, data, mainField);
                check_empty(x, y - 1, data, mainField);
                check_empty(x + 1, y, data, mainField);
                //check_empty(x + 1, y + 1, data, mainField);
                //check_empty(x + 1, y - 1, data, mainField);
            }
        }
        if(x == 9){
            if(y == 0){
                check_empty(x - 1, y, data, mainField);
                check_empty(x, y + 1, data, mainField);
                //check_empty(x - 1, y + 1, data, mainField);
            }
            if(y == 9){
                check_empty(x - 1, y, data, mainField);
                check_empty(x, y - 1, data, mainField);
                //check_empty(x - 1, y - 1, data, mainField);
            }
            if (y != 0 && y != 9) {
                check_empty(x, y + 1, data, mainField);
                check_empty(x, y - 1, data, mainField);
               // check_empty(x - 1, y + 1, data, mainField);
                //check_empty(x - 1, y - 1, data, mainField);
                check_empty(x - 1, y, data, mainField);
            }
        }
        if(x != 0 && x != 9){
            if(y == 0){
                check_empty(x - 1, y, data, mainField);
                check_empty(x + 1, y, data, mainField);
                check_empty(x, y + 1, data, mainField);
                //check_empty(x - 1, y + 1, data, mainField);
                //check_empty(x + 1, y + 1, data, mainField);
            }
            if(y == 9){
                check_empty(x - 1, y, data, mainField);
                check_empty(x + 1, y, data, mainField);
                check_empty(x, y - 1, data, mainField);
                //check_empty(x - 1, y - 1, data, mainField);
                //check_empty(x + 1, y - 1, data, mainField);
            }
            if (y != 0 && y != 9) {
                check_empty(x, y + 1, data, mainField);
                check_empty(x, y - 1, data, mainField);
                //check_empty(x - 1, y + 1, data, mainField);
                //check_empty(x - 1, y - 1, data, mainField);
                check_empty(x - 1, y, data, mainField);
                check_empty(x + 1, y, data, mainField);
                //check_empty(x + 1, y - 1, data, mainField);
                //check_empty(x + 1, y + 1, data, mainField);
            }
        }
    }
    private void setNumberCells(UserDataIn data, Field mainField) {
        Cell mainCell;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                mainCell = mainField.getCell(i, j);
                if (mainCell == ONE || mainCell == TWO || mainCell == THREE || mainCell == FOUR || mainCell == FIVE || mainCell == SIX || mainCell == SEVEN || mainCell == EIGHT){
                    if(i == 0){
                        if(j == 0)
                            if (data.field.getCell(i + 1, j) == EMPTY || data.field.getCell(i, j + 1) == EMPTY || data.field.getCell(i + 1, j + 1) == EMPTY){
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                  //  checkWin(data, mainField);
                                if (openedCells == 90) win = 1;
                                //data.score += 100;
                            }
                        if(j == 9)
                            if (data.field.getCell(i + 1, j) == EMPTY || data.field.getCell(i, j - 1) == EMPTY || data.field.getCell(i + 1, j - 1) == EMPTY){
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                                if (openedCells == 90) win = 1;
                               // data.score += 100;
                            }
                        if (j != 0 && j != 9)
                            if (data.field.getCell(i, j + 1) == EMPTY || data.field.getCell(i, j - 1) == EMPTY || mainField.getCell(i + 1, j) == EMPTY || data.field.getCell(i + 1, j - 1) == EMPTY || data.field.getCell(i + 1, j + 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                               if (openedCells == 90) win = 1;
                               // data.score += 100;
                            }
                    }
                    if(i == 9){
                        if(j == 0)
                            if (data.field.getCell(i - 1, j) == EMPTY || data.field.getCell(i, j + 1) == EMPTY || data.field.getCell(i - 1, j + 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                               if (openedCells == 90) win = 1;
                               // data.score += 100;
                            }
                        if(j == 9)
                            if (data.field.getCell(i - 1, j) == EMPTY || data.field.getCell(i, j - 1) == EMPTY || data.field.getCell(i - 1, j - 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                                if (openedCells == 90) win = 1;
                               //data.score += 100;
                            }
                        if (j != 0 && j != 9)
                            if (data.field.getCell(i, j + 1) == EMPTY || data.field.getCell(i, j - 1) == EMPTY || data.field.getCell(i - 1, j) == EMPTY || data.field.getCell(i - 1, j - 1) == EMPTY || data.field.getCell(i - 1, j + 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                                if (openedCells == 90) win = 1;
                                //data.score += 100;
                            }
                    }
                    if(i != 0 && i != 9) {
                        if (j == 0)
                            if (data.field.getCell(i - 1, j) == EMPTY || data.field.getCell(i + 1, j) == EMPTY || data.field.getCell(i, j + 1) == EMPTY || data.field.getCell(i + 1, j + 1) == EMPTY || data.field.getCell(i - 1, j + 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                                if (openedCells == 90) win = 1;
                                //data.score += 100;
                            }
                        if (j == 9)
                            if (data.field.getCell(i - 1, j) == EMPTY || data.field.getCell(i + 1, j) == EMPTY || data.field.getCell(i, j - 1) == EMPTY || data.field.getCell(i - 1, j - 1) == EMPTY || data.field.getCell(i + 1, j - 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                               if (openedCells == 90) win = 1;
                               // data.score += 100;
                            }
                        if (j != 0 && j != 9)
                            if (data.field.getCell(i, j + 1) == EMPTY || data.field.getCell(i, j - 1) == EMPTY || data.field.getCell(i - 1, j) == EMPTY || data.field.getCell(i + 1, j) == EMPTY || data.field.getCell(i + 1, j - 1) == EMPTY || data.field.getCell(i + 1, j + 1) == EMPTY || data.field.getCell(i -1, j + 1) == EMPTY || data.field.getCell(i - 1, j - 1) == EMPTY) {
                                data.openedCells++;
                                data.field.setCell(i, j, mainCell);
                                openedCells++;
                                //if (openedCells >= 90)
                                //  checkWin(data, mainField);
                               if (openedCells == 90) win = 1;
                               // data.score += 100;
                            }
                    }
                }
            }
        }
    }
    //главная функция работы с полем
    public void execCell(UserDataIn data, Cell localCell, Field mainField) {
        if (data.desire == Mode.OPEN) {
            //если BOMB, то игра окончена
            if (localCell == BOMB) {
                openedCells++;
                data.openedCells++;
                data.field.setCell(data.x, data.y, BOMB);
                lose = 1;           //game over
            }
            //если цифра, то просто устанавливаем ее на поле игрока
            if (localCell == ONE || localCell == TWO || localCell == THREE || localCell == FOUR || localCell == FIVE || localCell == SIX || localCell == SEVEN || localCell == EIGHT) {
                data.openedCells++;
                data.field.setCell(data.x, data.y, localCell);
                //data.score += 100;
                openedCells++;
                int countF = 0;
                if (openedCells == 90) win = 1;
                //checkWin(data, mainField);
            }
            //если пустая, то открываем все пустые вокруг нее
            if (localCell == EMPTY) {
                data.openedCells++;
                data.field.setCell(data.x, data.y, EMPTY);
                //data.score += 100;
                openedCells++;
                if (openedCells == 90) win = 1;
                setEmptyCells(data.x, data.y, data, mainField);//рекурсивная функция для открытия всех пустых клеток, которые связаны с пустой клеткой, которую открыл пользователь
                setNumberCells(data, mainField);
                if (openedCells == 90) win = 1;
            }
        }
        //если пользователь решил поставить флаг
        if (data.desire == Mode.FLAG) {
            data.field.setCell(data.x, data.y, FLAG);
        }
    }
    public boolean checkWin(){
        if (win == 1) return true;
        else return false;
    }
    public boolean checkLose(){
        if (lose == 1) return true;
        else return false;
    }
}
