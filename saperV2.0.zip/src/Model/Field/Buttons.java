package Model.Field;

import View.BaseWindow;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Buttons {
    public JButton[] buttons;
    public Buttons(BaseWindow baseWindow) throws IOException {
        buttons = new JButton[100];
        for (int i = 0; i < 100; i++){
            buttons[i] = new JButton("");
            buttons[i].setMargin(new Insets(0, 0, 0, 0));
            baseWindow.setPictures.setPicture( buttons[i],Cell.UNKNOWN);
        }
    }
    public void fillButtons(Field field, BaseWindow baseWindow) throws IOException {
        for (int i = 0; i < 10; i++){
            for (int j = 0; j < 10; j++){
                if(field.getCell(i, j) != Cell.UNKNOWN)
                    baseWindow.setPictures.setPicture(buttons[i + 10 * j], field.getCell(i, j));    //устанавливаем соответствующую картинку
            }
        }
    }
}
