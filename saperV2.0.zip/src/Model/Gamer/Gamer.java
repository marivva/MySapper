package Model.Gamer;

import Model.Field.Field;

public class Gamer {
    public Field gamerField;
    public int gamerScore;
    public String gamerName;
    public int openedCells;
    public Gamer(String gamerName){
        gamerScore = 0;
        this.gamerName = gamerName;
        gamerField = new Field(10);
        openedCells = 0;
    }
}
