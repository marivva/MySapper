package Model.Executer;

public enum Mode {
    UNKNOWN(0),
    OPEN(1),
    FLAG(2),
    EXIT(3),
    ABOUT(4),
    NEW_GAME(5),
    HIGH_SCORES(6);

    Mode(int i){
    }
}
