package Model.Executer;

import Controller.Check;
import Controller.Command;
import Controller.ConsoleCommands;
import Controller.UserDataIn;
import Model.Field.Field;
import Model.Field.Cell;
import Model.Gamer.Gamer;
import View.ConsoleView;
import View.GameView;

import java.io.IOException;

public class someWork {
    private Field mainField;
    private boolean new_game = false;
    private boolean gameOver = false;
    private boolean exit = false;
    private void executeDesire(Mode desire, GameView view){
        if (desire == Mode.NEW_GAME) {
            new_game = true;
            return;
        }
        if (desire == Mode.EXIT) {
            exit = true;
            return;
        }
        if (desire == Mode.ABOUT){
            view.printReference();
            return;
        }
        if (desire == Mode.HIGH_SCORES){
            view.printHighScores();
            return;
        }
    }
    public void run() throws IOException, InterruptedException {
        new_game = true;        //чтобы хоть раз зайти в цикл
        while (new_game) {
            Check check = new Check();      //класс для проверки
            new_game = false;           //если пользователь не введет new_game игра не будет исполняться
            gameOver = false;
            //инициализируем поле рефери (оно недоступно игроку)
            mainField = new Field(10);
            mainField.fillField();
            //создаем gameView
            GameView view = new ConsoleView();
            view.drawField(mainField, null, 0, null, null);//для отладки
            //создаем обработчик комманд пользователя
            UserDataIn userData = new UserDataIn();
            Command askUser = new ConsoleCommands();
            //создаем игрока
            askUser.getName();
            userData = askUser.getData();
            Gamer gamer = new Gamer(userData.name);
            //выводим все известное об игроке
            view.drawField(gamer.gamerField, gamer.gamerName, gamer.gamerScore, null, null);
            //основная работа - игра
            while (!gameOver) {
                askUser.getDesireAndCoordinates(gamer.gamerField);
                userData = askUser.getData();//координаты, введенные пользователем, что пользователь хочет сделать
                //если ввели не open/flag (то что не требует координат)
                if (userData.desire != Mode.OPEN && userData.desire != Mode.FLAG) {
                    executeDesire(userData.desire, view);
                    if (check.checkExit(userData.desire)) return;   //если exit
                    if (check.checkNewGame(userData.desire)) break; //если newgame
                }
                else {
                    Cell localCell = mainField.getCell(userData.x, userData.y);      //клетка в поле mainField
                    userData.field.execCell(userData, localCell, mainField);        //открываем или ставим флаг
                    gamer.gamerField = userData.field;
                    gamer.gamerScore = userData.openedCells * 100;
                    gamer.openedCells = userData.openedCells;
                    if (userData.lose == 1 || userData.win == 1) gameOver = true;   //если в процессе открытия бомба или выигрыш
                }
                view.drawField(gamer.gamerField, gamer.gamerName, gamer.gamerScore, null, null);
                if (check.checkWin(gamer.openedCells)){
                    gameOver = true;
                    view.printWinner();
                }
                if (gameOver){
                    if (askUser.getInf()) {
                        new_game = true;
                        view.saveScore(gamer.gamerName, gamer.gamerScore);
                    }
                    else{
                        view.drawField(mainField, gamer.gamerName, gamer.gamerScore, null, null);
                        view.saveScore(gamer.gamerName, gamer.gamerScore);
                        return;
                    }
                }
            }
        }
    }
}
